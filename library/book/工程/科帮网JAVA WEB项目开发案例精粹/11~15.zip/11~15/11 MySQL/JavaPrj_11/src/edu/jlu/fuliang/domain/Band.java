package edu.jlu.fuliang.domain;

public class Band extends CompositeSinger {
	private String name;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
