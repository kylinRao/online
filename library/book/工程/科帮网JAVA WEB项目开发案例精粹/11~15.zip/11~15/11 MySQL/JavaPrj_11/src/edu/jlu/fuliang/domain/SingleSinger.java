package edu.jlu.fuliang.domain;

public class SingleSinger extends Singer {
	private String name;
	private char sex;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public char getSex() {
		return sex;
	}

	public void setSex(char sex) {
		this.sex = sex;
	}
}
