package com.sanqing.common;
import java.util.*;

public class Tools {
	

}
