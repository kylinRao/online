package com.sanqing.bean;
/**
 * 
 * ͶƱƵ����
 *
 */
public class Channel {
	private int channelID;		//Ƶ��ID
	private String channelName;	//Ƶ������
	public int getChannelID() {
		return channelID;
	}
	public void setChannelID(int channelID) {
		this.channelID = channelID;
	}
	public String getChannelName() {
		return channelName;
	}
	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}
	
}
