package com.sanqing.service;

import java.util.Date;

public interface DianjiliangService {
	//�ж��Ƿ�����
	public boolean isVistor(int AId,String IP,Date time);
}
