package com.sanqing.service;

import com.sanqing.dao.DAO;
import com.sanqing.po.Customer;
/**
 * �ͻ�ҵ��ӿ�
 */
public interface CustomerService extends DAO<Customer> {

}
