package com.sanqing.service;

import com.sanqing.dao.DAO;
import com.sanqing.po.Order;
/**
 * ����ҵ��ӿ�
 */
public interface OrderService extends DAO<Order> {

}
