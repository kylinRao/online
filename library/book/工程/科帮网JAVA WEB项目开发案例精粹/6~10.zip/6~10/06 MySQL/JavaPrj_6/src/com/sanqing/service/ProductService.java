package com.sanqing.service;

import com.sanqing.dao.DAO;
import com.sanqing.po.Product;
/**
 * ��Ʒҵ��ӿ�
 */
public interface ProductService extends DAO<Product> {

}
