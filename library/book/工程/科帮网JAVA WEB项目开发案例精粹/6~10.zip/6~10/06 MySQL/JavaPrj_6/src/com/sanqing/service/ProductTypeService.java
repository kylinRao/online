package com.sanqing.service;

import com.sanqing.dao.DAO;
import com.sanqing.po.ProductType;
/**
 * ��Ʒ���ҵ��ӿ�
 */
public interface ProductTypeService extends DAO<ProductType> {

}
