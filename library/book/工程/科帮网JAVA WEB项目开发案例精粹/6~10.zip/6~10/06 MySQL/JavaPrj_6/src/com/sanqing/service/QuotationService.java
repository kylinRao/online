package com.sanqing.service;

import com.sanqing.dao.DAO;
import com.sanqing.po.Quotation;
/**
 * ����ҵ��ӿ�
 */
public interface QuotationService extends DAO<Quotation> {

}
