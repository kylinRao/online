package demo.servlet;

import demo.process.TulingApiProcess;

public class Itstyle {
   public static void main(String[] args) {
	   TulingApiProcess p = new  TulingApiProcess();
	   System.out.println(p.getTulingResult("小姐"));
}
}
