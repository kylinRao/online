package org.matrix.exception;

public class ExamException extends Exception {
	public ExamException(){
		
	}
	
	public ExamException(String x){
		super(x);
	}
}
