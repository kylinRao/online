import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JPanel;


public class BaseBox extends JPanel {
	
	int w = 30, h = 30;
	
	int type = 0; //��������ͣ�Ĭ��ΪĿ�ĵأ�1Ϊ���ӣ�2Ϊ��λ��3Ϊ�ռ䣬4Ϊǽ
	
	Image img = null;
	String filename = "";
	
	public BaseBox(int type, int x, int y){
		this.type = type;
		this.setBounds(x,y,w,h);
		if ( type == 0 )
			filename = "pot.gif";
		else if ( type == 1 )
			filename = "box.gif";
		else if ( type == 2 )
			filename = "ren.gif";
		else if ( type == 3 )
			filename = "box.gif";
		else 
			filename = "qiang.gif";
		img = Toolkit.getDefaultToolkit().getImage(this.getClass().getResource(filename));
	}
	
	
	public void setImg(String s){
		img = Toolkit.getDefaultToolkit().getImage(this.getClass().getResource(s));
		filename = s;
	}
	
	public String getFileName(){
		return filename;
	}
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g.drawImage(img,0,0,this);
	}


}
