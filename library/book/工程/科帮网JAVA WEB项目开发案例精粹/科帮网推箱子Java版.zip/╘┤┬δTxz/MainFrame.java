

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class MainFrame extends JFrame implements KeyListener,ActionListener,Runnable {
	
	List pid = new ArrayList();  //Ŀ��ص�id
	
	List bid = new ArrayList();  //����id
	
	List sid = new ArrayList();  //�ռ�id
	
	List qid = new ArrayList();  //ǽid
	
	String rid = "";
	
	int rows = 0;
	int cols = 0;
	
	int px, py; //�˳�ʼλ��
	
	
	int x ,y ,w = 30 ,h = 30;
	BaseBox ren;
	int rrx, rry, bbx, bby;//����λ��
	int bindex = -1;
	boolean isOver = false;
	
	int count;
	
	HashMap map = new HashMap(); //��������ļ���
	//������key����������,value������BoaseBox����
	
	int lvl = 1;  //��1��
	Container main ;
	
	JButton reset = new JButton("����");
	JButton next = new JButton("��һ��");
	JButton goback = new JButton("��һ��");
	
	JButton back = new JButton("���");
	JButton exit = new JButton("�˳�");
	JLabel mesLvl = new JLabel("�� 1 ��");
	JLabel numlvl = new JLabel("");
	JLabel timelvl = new JLabel("");
	int times = 0;//ʱ������
	int btime = 60; 
	Thread thread = null;
	
	public MainFrame (){
		
		main = this.getContentPane();
		
		main.setLayout(null);
		
		this.setTitle("Java��������");
		reset.setBounds(195,10,70,25);
		goback.setBounds(45,10,75,25);
		next.setBounds(120,10, 75,25);
		
		back.setBounds(265,10,70,25);
		exit.setBounds(340,10,70,25);
		mesLvl.setBounds(200,50, 120,30);
		timelvl.setBounds(320,50, 120,30);
		numlvl.setBounds(100,60,100,25);
		
		timelvl.setFont(new Font("Snap ITC",0, 25));
		timelvl.setForeground(Color.red);
		mesLvl.setFont(new Font("����Ҧ��",0, 26));
		numlvl.setFont(new Font("����",0, 18));
		numlvl.setForeground(Color.blue);
		
		next.addActionListener(this);
		back.addActionListener(this);
		exit.addActionListener(this);
		goback.addActionListener(this);
		this.setDefaultCloseOperation(3);
		
		reset.addActionListener(this);
		reset.addKeyListener(this);
		back.addKeyListener(this);
		goback.addKeyListener(this);
		exit.addKeyListener(this);
		next.addKeyListener(this);
		this.addKeyListener(this);
		
		
		int w1 = 700, h1 = 500;
		this.setSize(new Dimension(w1,h1));
		int x1 = (Toolkit.getDefaultToolkit().getScreenSize().width - w1) / 2; 
		int y1 = (Toolkit.getDefaultToolkit().getScreenSize().height - h1) / 2; 
		
		setBounds(x1,y1,w1,h1);
		setVisible(true);
		new DialogTime(this);
		init();
	}
	
	
	void init(){
		//��ȡ�ļ�����ȡ��ͼ����
		if ( !getMap() ){
			mesLvl.setText("�� " + lvl + " ��");
			return;
		}
		
		times = btime*pid.size();//ÿ������30��
		count = 0; //һ�������˶��ٲ�
		main.removeAll();
		main.add(reset);
		main.add(goback);
		main.add(next);
		
		main.add(back);
		main.add(exit);
		main.add(mesLvl);
		numlvl.setText("�ѽ���" + count + "��");
		main.add(numlvl);
		timelvl.setText("" + times);
		main.add(timelvl);
		
		back.setEnabled(false);
		reset.requestFocus(true);
		mesLvl.setText("�� " + lvl + " ��");
		
		
		isOver = false;
		int xx = 80;
		int yy = 100;
		int _type = 0;
		for ( int i = 0; i < rows*cols; i ++ ){
			if ( pid.contains("" + (i+1)) ){			
				_type = 0;
			}else if ( bid.contains("" + (i+1))){  //����
				_type = 1;
			}else if ( rid.equals("" + (i+1))){  //��λ
				_type = 2;
			}else if ( sid.contains("" + (i+1))){ //�ռ�
				_type = 3;
			}else if ( qid.contains("" + (i+1))){
				_type = 4;
			}
			if ( _type != 3 ){
				BaseBox b = new BaseBox(_type,xx,yy); 
				map.put("" + (i+1), b);
				if ( rid.equals("" + (i+1))){
					ren = b;
					px = xx; py = yy;  x = xx; y = yy;
					main.add(ren);
				}
			}
			
			if ( (i+1)% cols == 0 ){
				yy += 30;
				xx = 80;
			}
			else {
				xx += 30;
			}
		}
		Vector vv = new Vector(map.values());
		for ( int i = 0; i < vv.size(); i ++ ){
			BaseBox b  = (BaseBox) vv.get(i);
			if ( b.type == 1 ){
				main.add(b);
			}
		}
		for ( int i = 0; i < vv.size(); i ++ ){
			BaseBox b  = (BaseBox) vv.get(i);
			if ( b.type == 0 ){
				main.add(b);
			}
		}
		for ( int i = 0; i < vv.size(); i ++ ){
			BaseBox b  = (BaseBox) vv.get(i);
			if ( b.type == 3 ){
				main.add(b);
			}
		}
		for ( int i = 0; i < vv.size(); i ++ ){
			BaseBox b  = (BaseBox) vv.get(i);
			if ( b.type == 4 ){
				main.add(b);
			}
		}
		this.repaint();
		if ( thread != null && thread.isAlive() )
			thread.stop();
		thread = new Thread(this);
		thread.start();
		reset.requestFocus(true);
	}
	
	
	public boolean getMap(){
		if ( lvl < 1 ){
			JOptionPane.showMessageDialog(this,"���Ѿ��ǵ�һ���ˣ�");
			lvl = 1;
			return false;
		}
		try {
			InputStream in = this.getClass().getResourceAsStream("/box.dat");
                    	InputStreamReader isr = new InputStreamReader(in);
			BufferedReader br = new BufferedReader(isr);
			for ( int i = 0; i < (lvl-1)*5; i ++ ){
				br.readLine();
			}
			String[] line = br.readLine().trim().split(",");
			rows = Integer.parseInt(line[0]);
			cols = Integer.parseInt(line[1]);
			
			pid.clear(); bid.clear(); sid.clear();  qid.clear();  map.clear();
			line = br.readLine().trim().split(",");
			for ( int i = 0; i < line.length; i ++ ){
				pid.add(line[i]);
			}
			
			line = br.readLine().trim().split(",");
			for ( int i = 0; i < line.length; i ++ ){
				bid.add(line[i]);
			}
			
			rid = br.readLine().trim();
			
			line = br.readLine().trim().split(",");
			for ( int i = 0; i < line.length; i ++ ){
				sid.add(line[i]);
			}
			
			for ( int i = 1; i <= rows*cols; i ++ ){
				String si = "" + i;
				if ( !rid.equals(si) && !pid.contains(si) && ! bid.contains(si) && ! sid.contains(si)){
					qid.add(si);
				}
			}
			
			br.close();
			isr.close();
			in.close();
		} catch (Exception e) {
			System.out.println("�����ļ������ڻ�����Ϊ�գ�");
			JOptionPane.showMessageDialog(this,"���Ѿ������һ���ˣ�");
			lvl --; return false;
		}
		return true;
	}
	


	public void keyPressed(KeyEvent e) {
		if ( isOver ){
			back.setEnabled(false);
			return;
		}
		int c = e.getKeyCode();
		if ( c != 37 && c != 38 && c != 39 && c != 40 )
			return;
		
		int rx = x;
		int ry = y;
		
		if ( c == 37 ){
			x -= 30;
		}else if ( c == 38 ){
			y -= 30;
		}else if ( c == 39 ){
			x += 30;
		}else if ( c == 40 ){
			y += 30;
		}
		bindex = -1;
		Vector v = new Vector(map.values());
		for ( int i = 0; i < v.size(); i ++ ){
			BaseBox temp = (BaseBox) v.get(i);
			if ( x == temp.getX() && y == temp.getY()){				
				//ǰ����ǽ�߲���
				if ( temp.type == 4 ){
					x = rx; y = ry;
					bindex = -1;
					return;
				}
				//ǰ�������ӣ��ж�����ǰ����ʲô
				else if ( temp.type == 1 ){
					int nx = 30; int ny = 30;
					//��Ҫ֪���û����������ϻ����һ�����
					if ( rx > x ){
						nx = -30;
						ny = 0;
					} else if ( rx < x ){
						ny = 0;
					}
					if ( ry > y ){
						ny = -30;
						nx = 0;
					} else if ( ry < y ){
						nx = 0;
					}
					int tx = x + nx;   int ty = y + ny;
					boolean fg = false; //�Ƿ�ͼ��
					for ( int j = 0; j < v.size(); j ++ ){
						BaseBox obj = (BaseBox) v.get(j);
						if ( tx == obj.getX() && ty == obj.getY() ){
							//ǰ����ǽ�����ӣ��Ʋ���
							if ( obj.type == 4 || obj.type == 1 ){
								x = rx; y = ry;
								return;
							}
							else if ( obj.type == 0 ){
								//������Ŀ�ĵ�����û������
								boolean ck = false;
								for ( int k = 0; k < v.size(); k ++){
									if ( k == j )  continue;
									BaseBox kb = (BaseBox) v.get(k);
									if ( kb.getX() == obj.getX() && kb.getY() == obj.getY() && kb.type == 1){
										ck = true; break;
									}
								}
								if ( ck){
									x = rx; y = ry; return;
								}
								fg = true;
								break;
							}else {
								break;
							}
						}
					}
					if ( fg ) {
						temp.setImg("ok.gif");
						temp.repaint();
					}
					else if ( temp.getFileName().equals("ok.gif")){
						temp.setImg("box.gif");
						temp.repaint();
					}
					//�����ƶ�����
					bbx = temp.getX(); bby = temp.getY();
					bindex = i;
					temp.move(tx, ty);					
				}
			}
		}
		ren.move(x, y);
		count ++;
		this.numlvl.setText("�ѽ���" + count + "��");
		rrx = rx; rry = ry;
		back.setEnabled(true);
		if ( check()){
			isOver = true;
			JOptionPane.showMessageDialog(this, "��ϲ�����أ���һ������ " + count  + " ����");
		}
	}


	public boolean check(){
		int cnt = 0;
		Vector v = new Vector(map.values());
		Vector bv = new Vector();
		Vector pv = new Vector();
		for ( int i = 0; i < v.size(); i ++ ){
			BaseBox temp = (BaseBox) v.get(i);
			if ( temp.type == 1){
				bv.add(temp);
			}else  if ( temp.type == 0 ){
				pv.add(temp);
			}
		}
		
		for ( int i = 0; i < bv.size(); i ++ ){
			BaseBox temp = (BaseBox) bv.get(i);
			for ( int j = 0; j < pv.size(); j ++ ){
				BaseBox tb = (BaseBox) pv.get(j);
				if ( tb.getX() == temp.getX() && tb.getY() == temp.getY()){
					cnt ++;
					
					break;
				}
			}
		}
		if ( cnt == pv.size() )  return true;
		
		return false;
	}




	public void keyReleased(KeyEvent e) {
		// TODO �Զ����ɷ������
		
	}






	public void keyTyped(KeyEvent e) {
		// TODO �Զ����ɷ������
		
	}


	public void actionPerformed(ActionEvent e) {
		if ( e.getSource().equals(reset)){
			if ( JOptionPane.showConfirmDialog(this,"�����Ҫ���汾����","�˳�", JOptionPane.YES_NO_OPTION) == 0){
				times = 0;
				init();
			}
		}
		else if ( e.getSource().equals(back)){
			if ( bindex != -1 ){
				Vector v = new Vector(map.values());
				BaseBox temp = (BaseBox) v.get(bindex);
				temp.move(bbx,bby);
			}
			ren.move(rrx, rry);
			x = rrx; y = rry;
			back.setEnabled(false);
		}
		else if ( e.getSource().equals(exit)){
			if ( JOptionPane.showConfirmDialog(this,"�����Ҫ�˳���","�˳�", JOptionPane.YES_NO_OPTION) == 0){
				System.exit(0);
			}
		}
		else if ( e.getSource().equals(next)){
			lvl ++;
			init();
		}else if ( e.getSource().equals(goback)){
			lvl --;
			init();
		}
	}


	public void run() {
		while ( times > -1 && !isOver ){
			this.timelvl.setText("" + times);
			try {
				thread.sleep(1000);
				times --;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if ( times == -1 ){
			JOptionPane.showMessageDialog(this,"ʱ�䵽�ˣ����¿�ʼ�ɡ�");
			isOver = true;
		}
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MainFrame f = new MainFrame();
	}


}

class DialogTime extends JDialog implements ActionListener,WindowListener {
	
	JComboBox tlvl = new JComboBox();
	JButton bok, bexit;
	JLabel mes = new JLabel("����: " );
	
	Container m = null;
	MainFrame tf;
	
	public DialogTime(Frame f){
		super(f,"������", true);
		tf = (MainFrame) f;
		bok = new JButton("ȷ��");
		bexit = new JButton("�˳�");
		tlvl.addItem("����");
		tlvl.addItem("ҵ�༶");
		tlvl.addItem("������");
		
		m = this.getContentPane();
		m.setLayout(null);
		
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.setResizable(false);
		
		
		mes.setBounds(70, 50, 50, 24);
		tlvl.setBounds(120,50, 120, 24);
		
		bok.setBounds(90, 130, 65, 24);
		bexit.setBounds(160, 130, 65, 24);
		
		bok.addActionListener(this);
		bexit.addActionListener(this);
		m.add(mes); m.add(tlvl);  m.add(bok); m.add(bexit);

		
		int w = 300 , h = 220;
		int x = (Toolkit.getDefaultToolkit().getScreenSize().width - w) / 2; 
		int y = (Toolkit.getDefaultToolkit().getScreenSize().height - h) / 2; 
		this.setBounds(x, y , w, h);
		this.addWindowListener(this);
		this.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) {
		if ( e.getSource().equals(bexit)){
			System.exit(0);
		}
		else{
			Object obj = tlvl.getSelectedItem();
			if ( obj.equals("����")){
				tf.btime = 50;
			}
			else if ( obj.equals("ҵ�༶")){
				tf.btime = 30;
			}
			else if ( obj.equals("������")){
				tf.btime = 10;
			}
		}
		this.dispose();
	}

	public void windowActivated(WindowEvent e) {
		// TODO �Զ����ɷ������
		
	}

	public void windowClosed(WindowEvent e) {
		// TODO �Զ����ɷ������
		
	}

	public void windowClosing(WindowEvent e) {
		System.exit(0);
		
	}

	public void windowDeactivated(WindowEvent e) {
		// TODO �Զ����ɷ������
		
	}

	public void windowDeiconified(WindowEvent e) {
		// TODO �Զ����ɷ������
		
	}

	public void windowIconified(WindowEvent e) {
		// TODO �Զ����ɷ������
		
	}

	public void windowOpened(WindowEvent e) {
		// TODO �Զ����ɷ������
		
	}
	
}
